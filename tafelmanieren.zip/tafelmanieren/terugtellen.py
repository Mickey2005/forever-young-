import time



for x in range(30,0,-1):
    print(x)
    time.sleep(0.5)