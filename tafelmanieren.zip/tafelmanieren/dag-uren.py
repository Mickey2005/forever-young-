print("12AM")
for tijd in range(1,12):
    print(str(tijd) + " AM")
    
print("12PM")
for tijd in range(1,12):
    print(str(tijd) + " PM")